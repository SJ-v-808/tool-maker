#!/bin/bash
nul="\e[0m"
bred="\e[41m"
yellow="\e[33m"
blue="\e[34m"
white="\e[97m"
byellow="\e[43m"
bblue="\e[44m"
bwhite="\e[107m"
brand="\e[35m"

clear
echo -e -n "${bwhite}${yellow}To install tool-maker = [y] | To uninstall tool-maker = [n] --> ${nul}"
read ans
if [ $ans == "y" ]
then
    sudo mv tool-maker.sh /usr/local/bin
    sudo mv man-tm.sh /usr/local/bin
elif [ $ans == "n" ]
then
    sudo rm /usr/local/bin/tool-maker.sh
    sudo rm /usr/local/bin/man-tm.sh
    sudo rm tool-maker-build.sh
else
    clear
fi
