#!/bin/bash
edit=$1
if [ $edit == "e" ]
then 
    nano exe.sh
elif [ $edit == "r" ]
then
    chmod +x exe.sh
    ./exe.sh
else
    echo "error"
fi

