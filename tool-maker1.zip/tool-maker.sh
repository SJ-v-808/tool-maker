#!/bin/bash

nul="\e[0m"
bred="\e[41m"
yellow="\e[33m"
blue="\e[34m"
white="\e[97m"
byellow="\e[43m"
bblue="\e[44m"
bwhite="\e[107m"
brand="\e[35m"

source_file=$1
programming_language=$3
app_name=$2
run=$4

if [ $programming_language == "c" ]
then
    gcc $source_file -o $app_name
    if [ $run == "y" ]
    then
        ./$app_name
    elif [ $run == "n" ]
    then    
        echo -e "${byellow}${blue} build done ${nul}"
    else
        echo -e "${bred}${white} choose [y/n] ${nul}"
    fi
    
elif [ $programming_language == "cpp" ]
then
    g++ $source_file -o $app_name
    if [ $run == "y" ]
    then
        ./$app_name
    elif [ $run == "n" ]
    then    
        echo -e "${byellow}${blue} build done ${nul}"
    else
        echo -e "${bred}${white} choose [y/n] ${nul}"
    fi
elif [ $programming_language == "py" ]
then
    if [ $app_name == "nul" ]
    then 
        chmod +x $source_file 
        if [ $run == "y" ]
        then
            ./$source_file
        elif [ $run == "n" ]
        then    
            echo -e "${byellow}${blue} build done ${nul}"
        else
            echo -e "${bred}${white} choose [y/n] ${nul}"
        fi
    else 
       echo "${bred}invalid command${nul}"
    fi
elif [ $programming_language == "sh" ]
then
    if [ $app_name == "nul" ]
    then 
        chmod +x $source_file 
        if [ $run == "y" ]
        then
            ./$source_file
        elif [ $run == "n" ]
        then    
            echo -e "${byellow}${blue} build done ${nul}"
        else
            echo -e "${bred}${white} choose [y/n] ${nul}"
        fi
    else 
       echo "${bred}invalid command${nul}"
    fi
elif [ $programming_language == "c_sdl" ]
then
    gcc $source_file -lSDL2 -lSDL2main -o $app_name
    if [ $run == "y" ]
    then
        ./$app_name
    elif [ $run == "n" ]
    then    
        echo -e "${byellow}${blue} build done ${nul}"
    else
        echo -e "${bred}${white} choose [y/n] ${nul}"
    fi
elif [ $programming_language == "cpp_sdl" ]
then
    g++ $source_file -lSDL2 -lSDL2main -o $app_name
    if [ $run == "y" ]
    then
        ./$app_name
    elif [ $run == "n" ]
    then    
        echo -e "${byellow}${blue} build done ${nul}"
    else
        echo -e "${bred}${white} choose [y/n] ${nul}"
    fi
else 
    echo -e "${bwhite}${blue} invalid programming language ${nul}"
fi


